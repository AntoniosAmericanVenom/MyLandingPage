var estabravo = false;

// faz as configs iniciais 
function setup() {

  createCanvas(300, 300);
textAlign (CENTER, CENTER)
textSize (144);
}

function draw() {
  if (estabravo) {
background (random(65,255), 0, 0)
text ("😠", width / 2 + random (-10,10), height / 2 + random (-10,10));
} else {
background ("grey");
text ("😁", width / 2, height /2)
}

}
function mousePressed () {
if (estabravo==true) estabravo = false;
else if (estabravo==false) estabravo = true;
}