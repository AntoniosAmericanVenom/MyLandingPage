function setup() {
  createCanvas(400, 400);
}

function draw(){
background("grey")
var input= document.getElementById("marcelo").value

if(input>=7) carafeliz()
if(input<=5) caratriste()
if(input>5 && input<7) caraneutra()

}

function carafeliz() {
  background(220);
fill("yellow")
circle(200,200,200)
fill("black")
circle(150,180,20)
circle(250,180,20)
rect(160,250,85,10)
rect(160,220,10,30)
rect(235,220,10,30)
}
function caraneutra() {
background(220);
fill("yellow")
circle(200,200,200)
fill("black")
circle(150,180,20)
circle(250,180,20)
rect(160,250,85,10)
}
function caratriste() {
  background(220);
fill("yellow")
circle(200,200,200)
fill("black")
circle(150,180,20)
circle(250,180,20)
rect(160,220,85,10)
rect(160,220,10,30)
rect(235,220,10,30)
}
